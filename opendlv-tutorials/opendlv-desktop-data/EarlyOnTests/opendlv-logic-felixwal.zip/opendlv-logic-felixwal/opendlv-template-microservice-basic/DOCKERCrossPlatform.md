docker buildx build --platform=linux/amd64,linux/arm64 

# Check the slides from the lecturs