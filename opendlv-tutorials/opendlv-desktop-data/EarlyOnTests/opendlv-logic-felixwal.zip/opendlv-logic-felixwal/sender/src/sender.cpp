/*
 * Copyright (C) 2024 OpenDLV
 */

#include <cmath>
#include <cstdint>
#include <iostream>

#include "cluon-complete.hpp"
#include "opendlv-message-standard.hpp"

int16_t MSG_REQUEST = 1091;
int16_t MSG_SENDER = 1046;
int16_t ConferenceID = 132;
float multiplier = 2.5;


int32_t main(int32_t, char **)
{

  // Capture argv by value in the lambda function
  cluon::OD4Session od4(ConferenceID,
    [&od4](cluon::data::Envelope) noexcept {
      // create a new message of the type MSG_SENDER, use the argument of the main function for it
      opendlv::proxy::GroundSpeedReading msg;
      msg.groundSpeed(10); // Use argv[1] since argv[0] is the program name
      od4.send(msg);
    });

  // Rest of your code...
}



  // Below is the template code, it needs to be adjusted so that we listen to 
  // incomping messages of id 1091
  // if a message is received (opendlv.proxy.GroundSpeedRequest), we need to send a message with id 1046 (opendlv.proxy.GroundSpeedReading)
  // the message should contain the same data as the received message multiplied with float value (multiplier)


  // auto cmd = cluon::getCommandlineArguments(argc, argv);
  // if (!cmd.contains("cid")) {
  //   std::cout << argv[0] << " is an OpenDLV microservice." << std::endl;
  //   std::cout << "Usage: " << argv[0] << " "
  //             << "--cid=<conference id; e.g. 111> "
  //             << "[--verbose] " << std::endl;
  //   return 0;
  // }

  // uint16_t const cid = std::stoi(cmd.at("cid"));
  // bool const verbose = (cmd.count("verbose") != 0);

  // if (verbose) {
  //   std::cout << "Starting microservice." << std::endl;
  // }

  // cluon::OD4Session od4(cid);

  // auto onPedalPositionRequest{[&verbose](cluon::data::Envelope &&envelope) {
  //   auto const ppr =
  //       cluon::extractMessage<opendlv::proxy::PedalPositionRequest>(
  //           std::move(envelope));

  //   float pos = ppr.position();
  //   if (verbose) {
  //     std::cout << "Got pedal position " << pos << std::endl;
  //   }
  // }};

  // od4.dataTrigger(
  //     opendlv::proxy::PedalPositionRequest::ID(), onPedalPositionRequest);

  // while (od4.isRunning()) {
  //   std::this_thread::sleep_for(std::chrono::milliseconds(1000));
  // }

  // if (verbose) {
  //   std::cout << "Closing microservice." << std::endl;
  // }

  // return 0;
